package com.example.myapplication;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.telephony.CellSignalStrength;
import android.util.Log;

import androidx.annotation.Nullable;

public class dbConnect extends SQLiteOpenHelper {
    private static final String dbName = "findFriendsManager";
    private static final String dbTable = "users";
    private static final String Name_COL = "fullName";
    private static final int dbVersion = 1;
    private static final String ID = "id";
    private static final String emailCol = "emailAddress";
    private static final String passwordCol = "password";
    private static final String dobCol = "dob";//date of birth
    private static final String phoneNumberCol = "phoneNumber";
    private static final String DeliveryAddressCol = "deliveryAddress";
    private static final String bioCol = "bio";//gender
    private static User loggedInUser;
    public User getLoggedInUser(){
        return loggedInUser;
    }
    public void setLoggedInUser(User user){
        loggedInUser = user;
    }

    public dbConnect(@Nullable Context context) {
        super(context, dbName, null, dbVersion);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String query = "CREATE TABLE " + dbTable + " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Name_COL + " TEXT," +
                emailCol + " TEXT, " +
                passwordCol + " TEXT," +
                dobCol + " TEXT, " +
                phoneNumberCol + " TEXT," +
                DeliveryAddressCol + " TEXT," +
                bioCol + " TEXT)";
        sqLiteDatabase.execSQL(query);
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + dbTable);
        onCreate(sqLiteDatabase);
    }

    public void addUser(String fullname, String emailAddress, String password, String phoneNumber, String dob, String DeliveryAddress, String bio) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(Name_COL, fullname);
        values.put(emailCol, emailAddress);
        values.put(passwordCol, password);
        values.put(phoneNumberCol, phoneNumber);
        values.put(dobCol, dob);
        values.put(DeliveryAddressCol, DeliveryAddress);
        values.put(bioCol, bio);
        // 这里应该是唯一的传递


        long result = db.insert(dbTable, null, values);
        if (result == -1) {
            Log.e("DB_ERROR", "Failed to insert data");

        } else {
            Log.d("DN_INFO", "Data inserted successfully with ID: " + result);
        }
        db.close();
    }

    public String getPasswordForUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        // 确保 SQL 查询语句和列名正确
        String query = "SELECT " + passwordCol + " FROM " + dbTable + " WHERE " + Name_COL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        String storedPassword = null;

        if (cursor.moveToFirst()) {
            int passwordIndex = cursor.getColumnIndex("password");
            if (passwordIndex != -1) {
                storedPassword = cursor.getString(passwordIndex);
                Log.d("DB_DEBUG", "Password retrieved: " + storedPassword);
            } else {
                Log.e("DB_ERROR", "Column 'password' not found in query result.");
            }
        }


        return storedPassword;  // 如果未找到用户，返回 null
    }

    public String getEmailForUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT " + emailCol + " FROM " + dbTable + " WHERE " + Name_COL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        String storedEmail = null;

        if (cursor.moveToFirst()) {
            int emailIndex = cursor.getColumnIndex(emailCol);
            if (emailIndex != -1) {
                storedEmail = cursor.getString(emailIndex);
                Log.d("DB_DEBUG", "Email retrieved: " + storedEmail);
            } else {
                Log.e("DB_ERROR", "Column 'email' not found in query result.");
            }
        }

        cursor.close();
        return storedEmail;
    }

    public String getDOBForUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT " + dobCol + " FROM " + dbTable + " WHERE " + Name_COL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        String storedDOB = null;

        if (cursor.moveToFirst()) {
            int dobIndex = cursor.getColumnIndex(dobCol);
            if (dobIndex != -1) {
                storedDOB = cursor.getString(dobIndex);
                Log.d("DB_DEBUG", "DOB retrieved: " + storedDOB);
            } else {
                Log.e("DB_ERROR", "Column 'dob' not found in query result.");
            }
        }

        cursor.close();
        return storedDOB;
    }

    public String getPhoneNumberForUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT " + phoneNumberCol + " FROM " + dbTable + " WHERE " + Name_COL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        String storedPhoneNumber = null;

        if (cursor.moveToFirst()) {
            int phoneIndex = cursor.getColumnIndex(phoneNumberCol);
            if (phoneIndex != -1) {
                storedPhoneNumber = cursor.getString(phoneIndex);
                Log.d("DB_DEBUG", "Phone Number retrieved: " + storedPhoneNumber);
            } else {
                Log.e("DB_ERROR", "Column 'phone' not found in query result.");
            }
        }

        cursor.close();
        return storedPhoneNumber;
    }

    public String getAddressForUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT " + DeliveryAddressCol + " FROM " + dbTable + " WHERE " + Name_COL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        String storedAddress = null;

        if (cursor.moveToFirst()) {
            int addressIndex = cursor.getColumnIndex(DeliveryAddressCol);
            if (addressIndex != -1) {
                storedAddress = cursor.getString(addressIndex);
                Log.d("DB_DEBUG", "Address retrieved: " + storedAddress);
            } else {
                Log.e("DB_ERROR", "Column 'address' not found in query result.");
            }
        }

        cursor.close();
        return storedAddress;
    }

    public String getGender(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT " + bioCol + " FROM " + dbTable + " WHERE " + Name_COL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        String storedGender = null;

        if (cursor.moveToFirst()) {
            int genderIndex = cursor.getColumnIndex(bioCol);
            if (genderIndex != -1) {
                storedGender = cursor.getString(genderIndex);
                Log.d("DB_DEBUG", "Address retrieved: " + storedGender);
            } else {
                Log.e("DB_ERROR", "Column 'address' not found in query result.");
            }
        }

        cursor.close();
        return storedGender;
    }

    public User getUserDetails(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + dbTable + " WHERE " + Name_COL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});
        User user = null;
        if (cursor.moveToFirst()) {
            user = new User();
            user.setFullName(cursor.getString(1));
            user.setEmailAddress(cursor.getString(2));
            user.setPassword(cursor.getString(3));
            user.setDob(cursor.getString(4));
            user.setPhoneNumber(cursor.getString(5));
            user.setDeliveryAddress(cursor.getString(6));
            user.setBio(cursor.getString(7));

        }
        cursor.close();
        db.close();
        return user;
    }
    public int getUserID(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        // 确保 SQL 查询语句和列名正确
        String query = "SELECT " + ID + " FROM " + dbTable + " WHERE " + Name_COL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        int userID = -1;

        if (cursor.moveToFirst()) {
            userID = cursor.getInt(0);


                Log.d("DB_DEBUG", "id retrieved: " + userID);
            }
        else {
                Log.e("DB_ERROR", "Column 'address' not found in query result.");
            }


        cursor.close();


        return userID;  // 如果未找到用户，返回 null
    }
    public boolean updateUser(User user,String userName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Name_COL, user.getFullName());
        values.put(emailCol, user.getEmailAddress());
        values.put(passwordCol, user.getPassword());
        values.put(dobCol, user.getDob());
        values.put(phoneNumberCol, user.getPhoneNumber());
        values.put(DeliveryAddressCol, user.getDeliveryAddress());
        values.put(bioCol, user.getBio());
        int userID = getUserID(userName);
        if(userID != -1) {
            String[] whereArgs = {String.valueOf(userID)};
            int rowsAffected = db.update(
                    dbTable,                  // 表名
                    values,                        // 要更新的列和值
                    "id = ?",                      // WHERE 子句
                    whereArgs
            );
            db.close();
            return rowsAffected > 0;
        }
        else{
            db.close();
            return false;
        }
    }









}
