package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Register extends AppCompatActivity {
    Button BtnLogin,BtnRegister;
    EditText edtEmailAddress,edtUserName,edtDDB,edtPhoneNumber,edtGender,edtPassword,edtDeliveryAddress;
    TextView txtDisplayInfo;
    private dbConnect dbConnect;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        dbConnect = new dbConnect(Register.this);
        BtnLogin = findViewById(R.id.Login);
        BtnRegister = findViewById(R.id.register);
        edtEmailAddress = findViewById(R.id.email);
        edtUserName = findViewById(R.id.username);
        edtPassword = findViewById(R.id.password);
        edtDDB=findViewById(R.id.dob);
        edtDeliveryAddress= findViewById(R.id.DeliveryAddress);
        edtPhoneNumber = findViewById(R.id.PhoneNumber);
        edtGender = findViewById(R.id.gender);
        txtDisplayInfo = findViewById(R.id.txtDisplayInfo);
        BtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Register.this,userlogin.class);
                startActivity(i);
            }
        });
        BtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strFullName = edtUserName.getText().toString();
                String strEmail = edtEmailAddress.getText().toString();
                String strPassword = edtPassword.getText().toString();
                String strPhoneNumber = edtPhoneNumber.getText().toString();
                String strGender = edtGender.getText().toString();
                String strDDB = edtDDB.getText().toString();
                String deliveryAddress = edtDeliveryAddress.getText().toString();
                if(strFullName.isEmpty()&&strEmail.isEmpty()&&strPhoneNumber.isEmpty()&&strPassword.isEmpty()&&strDDB.isEmpty()&&strGender.isEmpty()){
                    txtDisplayInfo.setText("All Fidlds Required");
                }
                else if(!strEmail.contains("@")){
                    Toast.makeText(Register.this, "Please enter the correct format email", Toast.LENGTH_SHORT).show();
                }
                else if(strPassword.length()<6) {
                    Toast.makeText(Register.this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                }
                else{
                    dbConnect.addUser(strFullName,strEmail,strPassword,strDDB,strPhoneNumber,deliveryAddress,strGender);
                    Toast.makeText(Register.this, "Register successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}