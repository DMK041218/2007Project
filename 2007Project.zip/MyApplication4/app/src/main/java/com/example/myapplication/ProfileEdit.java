package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ProfileEdit extends AppCompatActivity {
    Button btnConfirm;
    EditText userName,email,password,dob,phoneNumber, deliveryAddress, gender;
    User logedInUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile_edit);
        dbConnect db = new dbConnect(this);
        userName = findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        dob = findViewById(R.id.dob);
        phoneNumber = findViewById(R.id.PhoneNumber);
        deliveryAddress = findViewById(R.id.DeliveryAddress);
        gender = findViewById(R.id.gender);
        logedInUser = db.getLoggedInUser();
        userName.setHint(logedInUser.getFullName());
        email.setHint(logedInUser.getEmailAddress());
        password.setHint(logedInUser.getPassword());
        dob.setHint(logedInUser.getDob());
        phoneNumber.setHint(logedInUser.getPhoneNumber());
        deliveryAddress.setHint(logedInUser.getDeliveryAddress());
        gender.setHint(logedInUser.getBio());
        btnConfirm = findViewById(R.id.Confirm);
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String updateFullName = userName.getText().toString();
                String updateEmail = email.getText().toString();
                String updatePassword = password.getText().toString();
                String updateDob = dob.getText().toString();
                String updatePhoneNumber = phoneNumber.getText().toString();
                String updateDeliveryAddress = deliveryAddress.getText().toString();
                String updateGender = gender.getText().toString();
                // 如果某项为空，保留原来的值
                if (updateFullName.isEmpty()) {
                    updateFullName = logedInUser.getFullName();
                }
                if (updateEmail.isEmpty()) {
                    updateEmail = logedInUser.getEmailAddress();
                }
                if (updatePassword.isEmpty()) {
                    updatePassword = logedInUser.getPassword();
                }
                if (updateDob.isEmpty()) {
                    updateDob = logedInUser.getDob();
                }
                if (updatePhoneNumber.isEmpty()) {
                    updatePhoneNumber = logedInUser.getPhoneNumber();
                }
                if (updateDeliveryAddress.isEmpty()) {
                    updateDeliveryAddress = logedInUser.getDeliveryAddress();
                }
                if (updateGender.isEmpty()) {
                    updateGender = logedInUser.getBio();
                }User updatedUser = new User();
                updatedUser.setFullName(updateFullName);
                updatedUser.setEmailAddress(updateEmail);
                updatedUser.setPassword(updatePassword);
                updatedUser.setDob(updateDob);
                updatedUser.setPhoneNumber(updatePhoneNumber);
                updatedUser.setDeliveryAddress(updateDeliveryAddress);
                updatedUser.setBio(updateGender);
                boolean isUpdated = db.updateUser(updatedUser,logedInUser.getFullName());
                if (isUpdated) {
                    logedInUser = updatedUser; // 更新全局的当前用户对象
                    db.setLoggedInUser(updatedUser); // 更新数据库的全局用户
                    Toast.makeText(ProfileEdit.this, "Saved successfully", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Log.e("PROFILE_UPDATE", "Failed to update user profile");
                }
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

}