package com.example.myapplication;

public class User {
    private String fullName;
    private String emailAddress;
    private String password;
    private String phoneNumber;
    private String deliveryAddress;
    private String dob;
    private String bio;
    public User(String fullName, String emailAddress, String password, String phoneNumber, String deliveryAddress, String dob, String bio) {
        this.fullName = fullName;
        this.emailAddress = emailAddress;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.deliveryAddress = deliveryAddress;
        this.dob = dob;
        this.bio = bio;
    }
    public User(){
        this.fullName = null;
        this.emailAddress = null;
        this.password = null;
        this.phoneNumber = null;
        this.deliveryAddress = null;
        this.dob = null;
        this.bio = null;
    }

    public String getBio() {
        return bio;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public String getDob() {
        return dob;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPassword() {
        return password;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setBio(String bio) {
        this.bio =bio;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

}
