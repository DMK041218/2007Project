package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class userlogin extends AppCompatActivity {
    Button btnRegister,btnSignIn;
    EditText edtUserName,edtPassword;
    TextView txtDisplayInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        txtDisplayInfo = findViewById(R.id.txtDisplayInfo);
        edtUserName = findViewById(R.id.username);
        edtPassword = findViewById(R.id.password);
        btnSignIn = findViewById(R.id.SignIn);
        btnRegister = findViewById(R.id.register);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i  = new Intent(userlogin.this,Register.class);
                startActivity(i);
            }
        });
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = edtUserName.getText().toString();
                String password = edtPassword.getText().toString();
                if(userName.isEmpty()||password.isEmpty()){
                    Toast.makeText(userlogin.this, "Please Enter All Fields", Toast.LENGTH_SHORT).show();
                }else {
                    // 创建数据库连接实例
                    dbConnect db = new dbConnect(userlogin.this);
                    // 查询数据库中的用户密码
                    String storedPassword = db.getPasswordForUser(userName);

                     if (storedPassword.equals(password)) {
                        // 密码匹配，登录成功
                         User user = db.getUserDetails(userName);
                         db.setLoggedInUser(user);
                         //Toast.makeText(userlogin.this, "Login successfully", Toast.LENGTH_SHORT).show();
                         Intent i = new Intent(userlogin.this, ProfileEdit.class);
                         startActivity(i);
                     } else {
                        // 密码错误
                         Toast.makeText(userlogin.this, "Incorrect Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

}